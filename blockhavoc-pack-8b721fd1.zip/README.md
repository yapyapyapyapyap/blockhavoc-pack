﻿# BlockHavoc Resource Pack

Minecraft/Paper target: 26.1.2
Resource pack format: 84

Batch 1 completed model IDs:
- moonlit_minnow
- siltback_codling
- reef_peeper
- glass_squidlet
- abyssal_starfin
- emberveil_manta
- void_halo
- meteor_knives
- gravity_well
- solar_flare
- starfall_comets
- plasma_orbitals
- black_hole_mine
- ion_lance
- nebula_drone
- cryo_nova
- stellar_lens
- quantum_clock
- nebula_magnet
- comet_fuel
- singularity_core
- red_giant
- void_prism
- cryo_matrix
- drone_swarm
- overclock_reactor
- surge_gravity_pulse
- surge_solar_wave
- surge_cryo_wave
- surge_burst
- surge_plasma_arc
- surge_ion_beam
- surge_drone_beam
- surge_meteor_trail
