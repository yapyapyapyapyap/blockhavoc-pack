﻿# BlockHavoc Resource Pack

Minecraft/Paper target: 26.1.2
Resource pack format: 84

## Packaging

Always build this pack from the workspace root with:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\package_blockhavoc_resource_pack.ps1
```

Do not build the zip with Windows-style entry paths. If the zip contains
entries like `assets\blockhavoc\items\void_halo.json`, Lunar/Minecraft will
download the pack but render every custom model as a purple/black missing
texture. Valid entries must look like `assets/blockhavoc/items/void_halo.json`.

The packaging script validates this before printing the `server.properties`
values.

## Third-party assets

- The fishing rod model and textures are derived from MB-3D Items Pack 2.2.0
  by mbanders and are distributed under the MIT License. See
  `THIRD_PARTY_LICENSES/MB-3D-Items-Pack-MIT.txt` for attribution and the full
  license text.

Batch 1 completed model IDs:
- moonlit_minnow
- siltback_codling
- reef_peeper
- glass_squidlet
- abyssal_starfin
- emberveil_manta
- void_halo
- knife
- gravity_well
- solar_flare
- starfall_comets
- starfall_impact
- plasma_orbitals
- black_hole_mine
- black_hole_flat
- ion_lance
- pet_drone
- cryo_nova
- stellar_lens
- quantum_clock
- nebula_magnet
- comet_fuel
- singularity_core
- red_giant
- void_prism
- cryo_matrix
- drone_swarm
- overclock_reactor
- surge_gravity_pulse
- surge_solar_wave
- surge_cryo_wave
- surge_burst
- surge_plasma_arc
- surge_ion_beam
- surge_drone_beam
- surge_meteor_trail
