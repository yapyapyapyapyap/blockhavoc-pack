﻿# BlockHavoc Alien Fishing Resource Pack

Minecraft/Paper target: 26.1.2
Resource pack format: 84

Model IDs:
- blockhavoc:abyssal_starfin
- blockhavoc:emberveil_manta

Use the ZIP beside this folder for server resource-pack hosting.
