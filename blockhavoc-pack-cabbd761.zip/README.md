﻿# BlockHavoc Resource Pack

Minecraft/Paper target: 26.1.2
Resource pack format: 84

Batch 1 completed model IDs:
- moonlit_minnow
- siltback_codling
- reef_peeper
- glass_squidlet
- abyssal_starfin
- emberveil_manta

